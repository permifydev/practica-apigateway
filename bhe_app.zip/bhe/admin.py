from django.contrib import admin

from bhe.models import ApiCallLog, BheConnection, BoletaEmitida


@admin.register(BheConnection)
class BheConnectionAdmin(admin.ModelAdmin):
    list_display = ("nombre", "vendor", "is_active", "creditos_cache", "updated_at")
    list_filter = ("is_active",)
    search_fields = ("nombre",)
    # El token no debería quedar visible a simple vista en el listado;
    # se puede ver/editar entrando al detalle igual.
    readonly_fields = ("created_at", "updated_at")


@admin.register(BoletaEmitida)
class BoletaEmitidaAdmin(admin.ModelAdmin):
    list_display = (
        "folio",
        "codigo",
        "emisor_rut",
        "receptor_rut",
        "periodo",
        "monto_bruto",
        "estado",
        "created_at",
    )
    list_filter = ("estado", "tipo_retencion", "periodo")
    search_fields = ("folio", "codigo", "emisor_rut", "receptor_rut")
    readonly_fields = ("respuesta_api", "created_at", "updated_at")


@admin.register(ApiCallLog)
class ApiCallLogAdmin(admin.ModelAdmin):
    list_display = ("endpoint", "metodo", "status_code", "ok", "created_at")
    list_filter = ("ok", "metodo")
    search_fields = ("endpoint",)
    readonly_fields = [f.name for f in ApiCallLog._meta.fields]
