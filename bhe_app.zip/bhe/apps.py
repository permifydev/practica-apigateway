from django.apps import AppConfig


class BheConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "bhe"
    verbose_name = "Boletas de Honorarios (SII / apigateway.cl)"
