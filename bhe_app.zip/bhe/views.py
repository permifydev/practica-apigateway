"""
Vistas de la app `bhe`, mapeadas al análisis CRUD del documento:

    CREATE  -> emitir_boleta            (POST /bhe/emitir/)
    READ    -> listar_emitidas          (GET  /bhe/emitidas/<emisor>/<periodo>/)
               listar_recibidas         (GET  /bhe/recibidas/<receptor>/<periodo>/)
               obtener_pdf              (GET  /bhe/emitidas/<codigo>/pdf/)
               verificar_autenticidad   (POST /bhe/consultas-por-terceros/)
    UPDATE  -> no aplica en SII; se agrupa "enviar por email" acá porque
               opera sobre una boleta ya emitida, sin modificarla.
               enviar_email             (POST /bhe/emitidas/<codigo>/email/)
    DELETE  -> anular_boleta (anulación lógica, no borra nada)
               (POST /bhe/emitidas/<emisor>/<folio>/anular/)
               observar_recibida (equivalente para boletas de terceros)
               (POST /bhe/recibidas/<emisor>/<folio>/observar/)

Cada vista sigue el patrón que ya usan en vendorapi/views.py: función +
decoradores de DRF. Por simplicidad todas usan permission AllowAny a nivel
de Django (autenticación de USUARIO), porque la seguridad real acá pasa
por tener una BheConnection válida - se resuelve con `_get_connection()`.
Si el piloto necesita que solo usuarios logueados del panel puedan usar
esto, cambia `AllowAny` por `IsAuthenticated` (import de
rest_framework.permissions).
"""

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from bhe.client import (
    ApiGatewayAuthError,
    ApiGatewayClient,
    ApiGatewayError,
    ApiGatewayNotFoundError,
    ApiGatewayRateLimitError,
)
from bhe.models import ApiCallLog, BheConnection, BoletaEmitida
from bhe.serializers import (
    AnularBoletaSerializer,
    BoletaEmitidaSerializer,
    EmitirBoletaSerializer,
    RutClaveSerializer,
)


def _get_connection(vendor=None) -> BheConnection:
    """Devuelve la conexión BHE activa a usar.

    Para el piloto, con que exista UNA conexión activa alcanza. Si más
    adelante cada Vendor tiene la suya, filtra por `vendor=vendor` acá.
    """
    qs = BheConnection.objects.filter(is_active=True)
    if vendor is not None:
        qs = qs.filter(vendor=vendor)
    connection = qs.order_by("-created_at").first()
    if connection is None:
        raise BheConnection.DoesNotExist(
            "No hay ninguna BheConnection activa configurada. Crea una desde el admin."
        )
    return connection


def _log_call(connection, endpoint, metodo, status_code, ok, detalle_error=None):
    ApiCallLog.objects.create(
        connection=connection,
        endpoint=endpoint,
        metodo=metodo,
        status_code=status_code,
        ok=ok,
        detalle_error=detalle_error,
    )


def _api_gateway_error_response(exc: ApiGatewayError, endpoint: str, metodo: str, connection=None):
    """Traduce un error del cliente de apigateway.cl a una respuesta HTTP
    de nuestra propia api, y deja registro en ApiCallLog."""
    if connection is not None:
        _log_call(connection, endpoint, metodo, exc.status_code, ok=False, detalle_error=str(exc))

    if isinstance(exc, ApiGatewayRateLimitError):
        http_status = status.HTTP_429_TOO_MANY_REQUESTS
    elif isinstance(exc, ApiGatewayAuthError):
        http_status = status.HTTP_401_UNAUTHORIZED
    elif isinstance(exc, ApiGatewayNotFoundError):
        http_status = status.HTTP_404_NOT_FOUND
    else:
        http_status = status.HTTP_502_BAD_GATEWAY  # la culpa es de la api externa, no de la nuestra

    return Response(
        {"detail": str(exc), "gateway_payload": exc.payload},
        status=http_status,
    )


# ----------------------------------------------------------------------
# CREATE
# ----------------------------------------------------------------------

@api_view(["POST"])
@permission_classes([AllowAny])
def emitir_boleta(request):
    """Crea (emite) una nueva boleta de honorarios."""
    serializer = EmitirBoletaSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = "/api/v2/sii/bhe/emitidas/emitir"

    try:
        data = client.emitir_boleta(
            rut=serializer.validated_data["rut"],
            clave=serializer.validated_data["clave"],
            boleta=serializer.to_boleta_payload(),
        )
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)

    # `data` es el contenido de la clave "data" de la respuesta real de
    # apigateway.cl: {"Encabezado": {"IdDoc": {"Folio":..., "CodigoBarras":
    # ..., "CodigoInferior": ...}, ...}, "Detalle": [...]}. Usamos
    # CodigoBarras como "codigo" porque la FAQ oficial dice que ese es el
    # código que sirve para pedir el pdf/email de la boleta después.
    encabezado = data.get("Encabezado", {})
    id_doc = encabezado.get("IdDoc", {})
    detalle = data.get("Detalle", [])
    monto_bruto_total = sum(item.get("MontoItem", 0) for item in detalle)

    boleta = BoletaEmitida.objects.create(
        connection=connection,
        codigo=id_doc.get("CodigoBarras") or id_doc.get("CodigoInferior") or "",
        folio=id_doc.get("Folio"),
        emisor_rut=serializer.validated_data["rut"],
        receptor_rut=(encabezado.get("Receptor") or {}).get("RUTRecep"),
        periodo=(id_doc.get("FchEmis") or "")[:7],  # AAAA-MM a partir de la fecha
        tipo_retencion=serializer.validated_data["tipo_retencion"],
        monto_bruto=monto_bruto_total,
        creado_por=request.user if request.user.is_authenticated else None,
        respuesta_api=data,
    )

    return Response(BoletaEmitidaSerializer(boleta).data, status=status.HTTP_201_CREATED)


# ----------------------------------------------------------------------
# READ
# ----------------------------------------------------------------------

@api_view(["POST"])
@permission_classes([AllowAny])
def listar_emitidas(request, emisor: str, periodo: str):
    """Lista las boletas emitidas por un emisor en un periodo (proxea a
    apigateway.cl; no depende solo de nuestra copia local).

    Nota: es POST y no GET aunque sea una operación de lectura, porque
    necesita rut+clave SII en el body — esos datos nunca deben viajar en
    la URL (quedarían en logs, historial del navegador, etc.).
    """
    auth = RutClaveSerializer(data=request.data)
    auth.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = f"/api/v2/sii/bte/emitidas/documentos/{emisor}/{periodo}"

    try:
        data = client.listar_emitidas(
            auth.validated_data["rut"], auth.validated_data["clave"], emisor, periodo
        )
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)
    return Response(data, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes([AllowAny])
def listar_recibidas(request, receptor: str, periodo: str):
    """Lista las boletas recibidas de terceros en un periodo. Ver nota de
    `listar_emitidas` sobre por qué es POST."""
    auth = RutClaveSerializer(data=request.data)
    auth.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = f"/api/v2/sii/bte/recibidas/documentos/{receptor}/{periodo}"

    try:
        data = client.listar_recibidas(
            auth.validated_data["rut"], auth.validated_data["clave"], receptor, periodo
        )
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)
    return Response(data, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes([AllowAny])
def obtener_pdf(request, codigo: str):
    """Obtiene el PDF (o su URL) de una boleta ya emitida. POST por el
    rut+clave en el body, igual que `listar_emitidas`."""
    auth = RutClaveSerializer(data=request.data)
    auth.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = f"/api/v2/sii/bhe/emitidas/pdf/{codigo}"

    try:
        data = client.obtener_pdf(auth.validated_data["rut"], auth.validated_data["clave"], codigo)
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)
    return Response(data, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes([AllowAny])
def verificar_autenticidad(request):
    """Verificación de autenticidad de una BHE por un tercero (código de
    barras, o combinación emisor/receptor/periodo/folio)."""
    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = "/api/v2/sii/bhe/consultas_por_terceros"

    try:
        data = client.verificar_autenticidad(request.data)
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)
    return Response(data, status=status.HTTP_200_OK)


# ----------------------------------------------------------------------
# UPDATE -> no aplica; "enviar por email" opera sobre una boleta existente
# sin modificarla, se agrupa acá por eso.
# ----------------------------------------------------------------------

@api_view(["POST"])
@permission_classes([AllowAny])
def enviar_email(request, codigo: str):
    """Envía (o reenvía) la boleta por email al receptor."""
    auth = RutClaveSerializer(data=request.data)
    auth.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = f"/api/v2/sii/bhe/emitidas/email/{codigo}"

    try:
        data = client.enviar_por_email(auth.validated_data["rut"], auth.validated_data["clave"], codigo)
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)
    return Response(data, status=status.HTTP_200_OK)


# ----------------------------------------------------------------------
# DELETE (lógico): anular / observar
# ----------------------------------------------------------------------

@api_view(["POST"])
@permission_classes([AllowAny])
def anular_boleta(request, emisor: str, folio: str):
    """Anula una boleta emitida (no la borra, queda marcada como anulada)."""
    serializer = AnularBoletaSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = f"/api/v2/sii/bhe/emitidas/anular/{emisor}/{folio}"
    motivo = serializer.validated_data.get("motivo")

    try:
        data = client.anular_boleta(
            serializer.validated_data["rut"],
            serializer.validated_data["clave"],
            emisor,
            folio,
            motivo=motivo,
        )
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)

    # Reflejamos la anulación en nuestra copia local, si la tenemos.
    BoletaEmitida.objects.filter(emisor_rut=emisor, folio=folio).update(
        estado=BoletaEmitida.ESTADO_ANULADA, motivo_anulacion=motivo or ""
    )

    return Response(data, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes([AllowAny])
def observar_recibida(request, emisor: str, folio: str):
    """Observa una boleta recibida de un tercero (equivalente a 'anular'
    pero del lado de las boletas que a nosotros nos emitieron)."""
    serializer = AnularBoletaSerializer(data=request.data)
    serializer.is_valid(raise_exception=True)

    try:
        connection = _get_connection()
    except BheConnection.DoesNotExist as exc:
        return Response({"detail": str(exc)}, status=status.HTTP_412_PRECONDITION_FAILED)

    client = ApiGatewayClient(token=connection.token_conexion)
    endpoint = f"/api/v2/sii/bhe/recibidas/observar/{emisor}/{folio}"
    motivo = serializer.validated_data.get("motivo")

    try:
        data = client.observar_recibida(
            serializer.validated_data["rut"],
            serializer.validated_data["clave"],
            emisor,
            folio,
            motivo=motivo,
        )
    except ApiGatewayError as exc:
        return _api_gateway_error_response(exc, endpoint, "POST", connection)

    _log_call(connection, endpoint, "POST", 200, ok=True)
    return Response(data, status=status.HTTP_200_OK)
