from rest_framework import serializers

from bhe.models import BoletaEmitida


class DetalleItemSerializer(serializers.Serializer):
    """Una línea de la boleta. Nombres de campo (NmbItem/MontoItem) tal
    cual los usa la doc oficial de apigateway.cl, para no tener que
    traducirlos antes de mandarlos."""

    NmbItem = serializers.CharField(max_length=80)
    MontoItem = serializers.IntegerField(min_value=1)


class ReceptorSerializer(serializers.Serializer):
    """Datos del receptor. Es opcional: la doc dice que se puede omitir
    o mandar RUTRecep='0-0' para una boleta sin receptor identificado."""

    RUTRecep = serializers.CharField(max_length=20)
    RznSocRecep = serializers.CharField(max_length=100, required=False, allow_blank=True)
    DirRecep = serializers.CharField(max_length=150, required=False, allow_blank=True)
    CmnaRecep = serializers.CharField(max_length=60, required=False, allow_blank=True)


class EmitirBoletaSerializer(serializers.Serializer):
    """Valida el body que llega a nuestro endpoint /bhe/emitir/.

    Estructura CONFIRMADA contra la doc oficial
    (apigateway.cl/products/sii/bhe): la boleta se arma como
    Encabezado.IdDoc / Encabezado.Emisor / Encabezado.Receptor + Detalle
    (lista de ítems). El rut+clave del emisor van aparte y nunca se
    guardan en nuestra base.
    """

    rut = serializers.CharField(help_text="Rut del emisor SII, ej. 12345678-9 (sin puntos).")
    clave = serializers.CharField(
        write_only=True, help_text="Clave SII del emisor. Nunca se guarda en nuestra base."
    )
    fecha_emision = serializers.DateField(
        required=False, help_text="AAAA-MM-DD. Si se omite, se usa la fecha de hoy."
    )
    tipo_retencion = serializers.ChoiceField(
        choices=[0, 1, 2],
        default=1,
        help_text="0=sin retención, 1=retiene el receptor, 2=retiene el emisor.",
    )
    receptor = ReceptorSerializer(required=False)
    detalle = DetalleItemSerializer(many=True, min_length=1)

    def to_boleta_payload(self) -> dict:
        """Arma el sub-diccionario 'boleta' (Encabezado + Detalle) que
        espera el cliente. rut/clave se pasan aparte, no van acá."""
        from datetime import date

        data = self.validated_data
        fecha = data.get("fecha_emision") or date.today()

        encabezado = {
            "IdDoc": {
                "FchEmis": fecha.isoformat(),
                "TipoRetencion": data["tipo_retencion"],
            },
            "Emisor": {"RUTEmisor": data["rut"]},
        }
        if data.get("receptor"):
            encabezado["Receptor"] = dict(data["receptor"])

        return {
            "Encabezado": encabezado,
            "Detalle": [dict(item) for item in data["detalle"]],
        }


class RutClaveSerializer(serializers.Serializer):
    """Reutilizado por las operaciones que necesitan re-autenticarse
    contra el SII (listar, pdf, email, anular, observar). El rut+clave
    nunca se guardan; viajan solo dentro del request."""

    rut = serializers.CharField()
    clave = serializers.CharField(write_only=True)


class AnularBoletaSerializer(RutClaveSerializer):
    motivo = serializers.CharField(required=False, allow_blank=True)


class BoletaEmitidaSerializer(serializers.ModelSerializer):
    class Meta:
        model = BoletaEmitida
        fields = [
            "id",
            "codigo",
            "folio",
            "emisor_rut",
            "receptor_rut",
            "periodo",
            "tipo_retencion",
            "monto_bruto",
            "monto_liquido",
            "estado",
            "motivo_anulacion",
            "created_at",
            "updated_at",
        ]
        read_only_fields = fields
