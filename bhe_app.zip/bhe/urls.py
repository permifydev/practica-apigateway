from django.urls import path

from bhe import views

app_name = "bhe"

urlpatterns = [
    # CREATE
    path("emitir/", views.emitir_boleta, name="emitir_boleta"),
    # READ
    path("emitidas/<str:emisor>/<str:periodo>/", views.listar_emitidas, name="listar_emitidas"),
    path("recibidas/<str:receptor>/<str:periodo>/", views.listar_recibidas, name="listar_recibidas"),
    path("emitidas/<str:codigo>/pdf/", views.obtener_pdf, name="obtener_pdf"),
    path("consultas-por-terceros/", views.verificar_autenticidad, name="verificar_autenticidad"),
    # UPDATE (no aplica; ver views.py) -> enviar email
    path("emitidas/<str:codigo>/email/", views.enviar_email, name="enviar_email"),
    # DELETE (lógico)
    path("emitidas/<str:emisor>/<str:folio>/anular/", views.anular_boleta, name="anular_boleta"),
    path(
        "recibidas/<str:emisor>/<str:folio>/observar/",
        views.observar_recibida,
        name="observar_recibida",
    ),
]
