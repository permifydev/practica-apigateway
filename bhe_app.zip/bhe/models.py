"""
Modelos de la app `bhe`.

Guardamos dos cosas localmente:

1) BheConnection: la credencial de conexión contra apigateway.cl
   (el "token de conexión" que va en el header Authorization) y,
   opcionalmente, a qué Vendor de SilverLunch pertenece.

2) BoletaEmitida: un espejo local de cada boleta que emitimos, para no
   depender 100% de volver a consultar la api externa cada vez, y para
   llevar un registro propio (auditoría, soporte, y control de créditos
   gastados).

Nota de seguridad para el piloto: el rut+clave SII NO se guarda nunca en
estos modelos. Viaja en el body de cada request hacia apigateway.cl y no
se persiste en nuestra base de datos. Si más adelante se necesita
recordar la clave para no pedirla cada vez, hay que cifrarla (por ejemplo
con `django-cryptography` o un KMS) — no guardarla en texto plano.
"""

from django.conf import settings
from django.db import models

# Nota: el FK a Vendor se referencia como string ("vendor.Vendor") más abajo,
# así que no hace falta importar el modelo acá. Si este app se usa FUERA de
# SilverLunch (sin la app "vendor"), basta con quitar el campo `vendor` de
# BheConnection y la migración correspondiente.


class BheConnection(models.Model):
    """Una conexión (token) contra apigateway.cl.

    apigateway.cl permite tener más de una "conexión" por cuenta (cada
    una con su propio saldo de créditos), así que este modelo soporta
    varias conexiones activas a la vez.
    """

    nombre = models.CharField(
        max_length=100,
        help_text="Nombre interno para identificar esta conexión (ej. 'Piloto BHE - Producción').",
    )
    vendor = models.ForeignKey(
        "vendor.Vendor",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name="bhe_connections",
        help_text="Vendor de SilverLunch dueño de esta conexión, si aplica.",
    )
    token_conexion = models.CharField(
        max_length=255,
        help_text="Token de conexión entregado por apigateway.cl (header Authorization).",
    )
    is_active = models.BooleanField(default=True)
    creditos_cache = models.DecimalField(
        max_digits=10,
        decimal_places=3,
        null=True,
        blank=True,
        help_text="Último saldo de créditos conocido (informativo, se refresca al consultar).",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Conexión BHE"
        verbose_name_plural = "Conexiones BHE"

    def __str__(self):
        return f"{self.nombre} ({'activa' if self.is_active else 'inactiva'})"


class BoletaEmitida(models.Model):
    """Registro local de una boleta de honorarios emitida vía apigateway.cl."""

    ESTADO_EMITIDA = "emitida"
    ESTADO_ANULADA = "anulada"
    ESTADO_CHOICES = [
        (ESTADO_EMITIDA, "Emitida"),
        (ESTADO_ANULADA, "Anulada"),
    ]

    RETENCION_SIN = 0
    RETENCION_RECEPTOR = 1
    RETENCION_EMISOR = 2
    RETENCION_CHOICES = [
        (RETENCION_SIN, "Sin retención"),
        (RETENCION_RECEPTOR, "Retiene el receptor"),
        (RETENCION_EMISOR, "Retiene el emisor"),
    ]

    connection = models.ForeignKey(
        BheConnection, on_delete=models.PROTECT, related_name="boletas"
    )
    codigo = models.CharField(
        max_length=100,
        unique=True,
        help_text="Código único que entrega apigateway.cl al emitir (se usa para pdf/email/consultas).",
    )
    folio = models.CharField(max_length=50, blank=True, null=True)
    emisor_rut = models.CharField(max_length=20)
    receptor_rut = models.CharField(max_length=20, blank=True, null=True)
    periodo = models.CharField(
        max_length=7, help_text="Formato AAAA-MM, útil para las consultas por periodo."
    )
    tipo_retencion = models.PositiveSmallIntegerField(choices=RETENCION_CHOICES, default=RETENCION_SIN)
    monto_bruto = models.DecimalField(max_digits=12, decimal_places=2)
    monto_liquido = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default=ESTADO_EMITIDA)
    motivo_anulacion = models.CharField(max_length=255, blank=True, null=True)
    creado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )
    respuesta_api = models.JSONField(
        blank=True, null=True, help_text="Respuesta cruda de apigateway.cl, para auditoría/debug."
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Boleta emitida (BHE)"
        verbose_name_plural = "Boletas emitidas (BHE)"
        ordering = ["-created_at"]

    def __str__(self):
        return f"BHE {self.folio or self.codigo} - {self.estado}"


class ApiCallLog(models.Model):
    """Bitácora simple de cada llamada a apigateway.cl.

    Sirve para diagnosticar problemas de créditos/rate-limit (429) y para
    tener trazabilidad de qué se llamó y cuándo, sin exponer credenciales.
    """

    connection = models.ForeignKey(
        BheConnection, on_delete=models.CASCADE, related_name="logs", null=True, blank=True
    )
    endpoint = models.CharField(max_length=255)
    metodo = models.CharField(max_length=10)
    status_code = models.PositiveIntegerField(null=True, blank=True)
    ok = models.BooleanField(default=False)
    detalle_error = models.CharField(max_length=500, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Log de llamada BHE"
        verbose_name_plural = "Logs de llamadas BHE"
        ordering = ["-created_at"]

    def __str__(self):
        return f"[{self.status_code}] {self.metodo} {self.endpoint}"
