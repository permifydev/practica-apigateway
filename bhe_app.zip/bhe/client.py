"""
Cliente para la API de apigateway.cl (módulo BHE del SII).

Centraliza TODAS las llamadas HTTP en un solo lugar, para que las vistas
(views.py) no tengan que saber nada de URLs, headers ni manejo de errores
de la api externa. Así, si apigateway.cl cambia una ruta o el formato de
respuesta, solo se toca este archivo.

Uso típico desde una vista:

    from bhe.client import ApiGatewayClient, ApiGatewayError

    client = ApiGatewayClient(token=connection.token_conexion)
    try:
        data = client.emitir_boleta(rut="11.111.111-1", clave="****", payload={...})
    except ApiGatewayRateLimitError:
        # 429 -> avisar al usuario que espere
    except ApiGatewayError as exc:
        # cualquier otro error de la api externa
        ...
"""

from __future__ import annotations

import logging
from typing import Any

import requests
from django.conf import settings

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://apigateway.cl"
DEFAULT_TIMEOUT = 20  # segundos. Las apis de SII a veces son lentas.


class ApiGatewayError(Exception):
    """Error genérico al llamar a apigateway.cl."""

    def __init__(self, message: str, status_code: int | None = None, payload: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


class ApiGatewayAuthError(ApiGatewayError):
    """Token de conexión inválido/ausente, o rut+clave SII rechazados (401/403)."""


class ApiGatewayRateLimitError(ApiGatewayError):
    """Se superaron las 60 consultas/minuto (HTTP 429)."""


class ApiGatewayNotFoundError(ApiGatewayError):
    """El recurso consultado (boleta, folio, etc.) no existe (404)."""


class ApiGatewayClient:
    """Wrapper delgado sobre `requests` para hablar con apigateway.cl."""

    def __init__(self, token: str, base_url: str | None = None, timeout: int = DEFAULT_TIMEOUT):
        if not token:
            raise ApiGatewayAuthError("Falta el token de conexión de apigateway.cl.")
        self.token = token
        self.base_url = (base_url or getattr(settings, "APIGATEWAY_BASE_URL", DEFAULT_BASE_URL)).rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()

    # ------------------------------------------------------------------
    # Mecánica interna
    # ------------------------------------------------------------------

    def _headers(self) -> dict:
        # Confirmado contra la doc oficial (products/sii/bhe): el formato
        # es "Token <token>", NO "Bearer <token>".
        return {
            "Authorization": f"Token {self.token}",
            "Content-Type": "application/json",
        }

    @staticmethod
    def _auth_block(rut: str, clave: str) -> dict:
        """Bloque de autenticación SII que va en el body de (al parecer)
        todas las operaciones que actúan a nombre de un contribuyente
        específico. Formato confirmado en el ejemplo oficial de 'emitir'."""
        return {"auth": {"pass": {"rut": rut, "clave": clave}}}

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.base_url}{path}"
        try:
            response = self.session.request(
                method,
                url,
                headers=self._headers(),
                timeout=self.timeout,
                **kwargs,
            )
        except requests.exceptions.Timeout as exc:
            raise ApiGatewayError(f"Timeout llamando a {path}") from exc
        except requests.exceptions.ConnectionError as exc:
            raise ApiGatewayError(f"No se pudo conectar a apigateway.cl ({path})") from exc

        return self._handle_response(method, path, response)

    def _handle_response(self, method: str, path: str, response: requests.Response) -> dict:
        # Intentamos parsear JSON incluso en errores, porque apigateway.cl
        # normalmente manda el detalle del error ahí.
        try:
            data = response.json()
        except ValueError:
            data = {"raw": response.text}

        if response.status_code == 401 or response.status_code == 403:
            raise ApiGatewayAuthError(
                "Autenticación rechazada (token de conexión o rut/clave SII inválidos).",
                status_code=response.status_code,
                payload=data,
            )
        if response.status_code == 404:
            raise ApiGatewayNotFoundError(
                "Recurso no encontrado.", status_code=response.status_code, payload=data
            )
        if response.status_code == 429:
            raise ApiGatewayRateLimitError(
                "Se superó el límite de 60 consultas por minuto.",
                status_code=response.status_code,
                payload=data,
            )
        if not response.ok:
            raise ApiGatewayError(
                f"Error {response.status_code} llamando a {method} {path}.",
                status_code=response.status_code,
                payload=data,
            )

        return data

    # ------------------------------------------------------------------
    # CREATE
    # ------------------------------------------------------------------

    def emitir_boleta(self, rut: str, clave: str, boleta: dict) -> dict:
        """POST /api/v2/sii/bhe/emitidas/emitir

        Formato de body CONFIRMADO contra la doc oficial
        (apigateway.cl/products/sii/bhe):

            {
              "auth": {"pass": {"rut": "...", "clave": "..."}},
              "boleta": {
                "Encabezado": {
                  "IdDoc": {"FchEmis": "2025-03-26", "TipoRetencion": 1},
                  "Emisor": {"RUTEmisor": "..."},
                  "Receptor": {"RUTRecep": "...", "RznSocRecep": "...",
                               "DirRecep": "...", "CmnaRecep": "..."}
                },
                "Detalle": [{"NmbItem": "...", "MontoItem": 500000}, ...]
              }
            }

        `boleta` acá es ese sub-diccionario con "Encabezado" y "Detalle" ya
        armado (ver serializers.EmitirBoletaSerializer.to_gateway_payload).
        La respuesta viene envuelta en {"data": {...}}; este método
        devuelve directamente ese "data" para que quien llama no tenga que
        desenvolverlo cada vez.
        """
        body = self._auth_block(rut, clave)
        body["boleta"] = boleta
        result = self._request("POST", "/api/v2/sii/bhe/emitidas/emitir", json=body)
        return result.get("data", result)

    # ------------------------------------------------------------------
    # READ
    # ------------------------------------------------------------------

    def listar_emitidas(self, rut: str, clave: str, emisor: str, periodo: str) -> dict:
        """POST /api/v2/sii/bte/emitidas/documentos/{emisor}/{periodo}

        `periodo` puede ser mensual (AAAA-MM) o diario según la doc.

        NOTA DE CONFIANZA: el formato exacto del body de ESTE endpoint no
        está confirmado 1 a 1 contra la doc (no pude leer el explorador
        interactivo, es una app JS). Lo que SÍ está confirmado es que el
        acceso al SII requiere rut+clave "en cada llamada" (documento
        original de análisis), así que mando el mismo bloque `auth.pass`
        que se confirmó para `emitir`. Verifica esto con una llamada real
        o con el equipo de soporte de apigateway.cl antes de producción.
        """
        return self._request(
            "POST",
            f"/api/v2/sii/bte/emitidas/documentos/{emisor}/{periodo}",
            json=self._auth_block(rut, clave),
        )

    def listar_recibidas(self, rut: str, clave: str, receptor: str, periodo: str) -> dict:
        """POST /api/v2/sii/bte/recibidas/documentos/{receptor}/{periodo}

        Mismo aviso de confianza que `listar_emitidas`.
        """
        return self._request(
            "POST",
            f"/api/v2/sii/bte/recibidas/documentos/{receptor}/{periodo}",
            json=self._auth_block(rut, clave),
        )

    def obtener_pdf(self, rut: str, clave: str, codigo: str) -> dict:
        """POST /api/v2/sii/bhe/emitidas/pdf/{codigo}

        Mismo aviso de confianza que `listar_emitidas`.
        """
        return self._request(
            "POST",
            f"/api/v2/sii/bhe/emitidas/pdf/{codigo}",
            json=self._auth_block(rut, clave),
        )

    def verificar_autenticidad(self, criterios: dict) -> dict:
        """POST /api/v2/sii/bhe/consultas_por_terceros

        `criterios`: código de barras, o combinación
        emisor/receptor/período/folio, según lo que se use para validar.
        """
        return self._request("POST", "/api/v2/sii/bhe/consultas_por_terceros", json=criterios)

    # ------------------------------------------------------------------
    # UPDATE -> no aplica en SII (los documentos tributarios no se editan)
    # ------------------------------------------------------------------

    def enviar_por_email(self, rut: str, clave: str, codigo: str) -> dict:
        """POST /api/v2/sii/bhe/emitidas/email/{codigo}

        No es una edición del documento, pero se agrupa junto a las
        operaciones sobre una boleta ya emitida. Mismo aviso de confianza
        que `listar_emitidas` respecto al body exacto.
        """
        return self._request(
            "POST",
            f"/api/v2/sii/bhe/emitidas/email/{codigo}",
            json=self._auth_block(rut, clave),
        )

    # ------------------------------------------------------------------
    # DELETE (lógico) -> anular / observar
    # ------------------------------------------------------------------

    def anular_boleta(self, rut: str, clave: str, emisor: str, folio: str, motivo: str | None = None) -> dict:
        """POST /api/v2/sii/bhe/emitidas/anular/{emisor}/{folio}

        Mismo aviso de confianza que `listar_emitidas` respecto al body
        exacto; el campo `motivo` (causa de anulación) sí está mencionado
        en la doc oficial del producto, pero no su nombre exacto de campo.
        """
        body = self._auth_block(rut, clave)
        if motivo:
            body["motivo"] = motivo
        return self._request(
            "POST", f"/api/v2/sii/bhe/emitidas/anular/{emisor}/{folio}", json=body
        )

    def observar_recibida(self, rut: str, clave: str, emisor: str, folio: str, motivo: str | None = None) -> dict:
        """POST /api/v2/sii/bhe/recibidas/observar/{emisor}/{folio}

        Mismo aviso de confianza que `anular_boleta`.
        """
        body = self._auth_block(rut, clave)
        if motivo:
            body["motivo"] = motivo
        return self._request(
            "POST", f"/api/v2/sii/bhe/recibidas/observar/{emisor}/{folio}", json=body
        )
